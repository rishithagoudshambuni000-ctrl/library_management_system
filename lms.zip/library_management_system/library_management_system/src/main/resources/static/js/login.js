const API_URL = "http://localhost:8080/api/v1/users";

async function login() {

    const username = document.getElementById("username").value.trim();
    const password = document.getElementById("password").value.trim();

    if (username === "" || password === "") {
        alert("Please enter Username and Password");
        return;
    }

    try {

        const response = await fetch(API_URL + "/login", {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({
                username,
                password
            })

        });

        if (!response.ok) {
            alert("Invalid Username or Password");
            return;
        }

        localStorage.setItem("loggedIn", "true");

        window.location.href = "dashboard.html";

    } catch (error) {

        console.error(error);

        alert("Server Error");

    }
}