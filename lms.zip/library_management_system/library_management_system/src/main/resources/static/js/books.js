const API_URL = "http://localhost:8080/api/v1/books";

// Load books when page opens
window.onload = function () {
    loadBooks();
};

// ==========================
// LOAD BOOKS
// ==========================
async function loadBooks() {

    try {

        const response = await fetch(API_URL);

        const books = await response.json();

        const tableBody = document.getElementById("bookBody");

        tableBody.innerHTML = "";

        books.forEach(book => {

            tableBody.innerHTML += `

                <tr>

                    <td>${book.id}</td>
                    <td>${book.title}</td>
                    <td>${book.author}</td>
                    <td>${book.category}</td>
                    <td>${book.quantity}</td>
                    <td>${book.availableQuantity}</td> 

                    <td>

                        <button class="edit"
                            onclick="editBook(${book.id})">

                            Edit

                        </button>

                        <button class="delete"
                            onclick="deleteBook(${book.id})">

                            Delete

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch(error){

        console.log(error);

        alert("Unable to load books.");

    }

}

// ==========================
// SEARCH
// ==========================

function searchBook(){

    let input = document
        .getElementById("searchBook")
        .value
        .toLowerCase();

    let rows = document.querySelectorAll("#bookBody tr");

    rows.forEach(row=>{

        let data = row.innerText.toLowerCase();

        row.style.display =
            data.includes(input) ? "" : "none";

    });

}

// ==========================
// DELETE
// ==========================

async function deleteBook(id){

    if(!confirm("Delete this book?")){

        return;

    }

    try{

        const response = await fetch(API_URL+"/"+id,{

            method:"DELETE"

        });

        const result = await response.json();

        alert(result.message);

        loadBooks();

    }

    catch(error){

        alert("Server Error");

    }

}

// ==========================
// EDIT
// ==========================

function editBook(id){

    window.location.href = "edit-book.html?id=" + id;

}