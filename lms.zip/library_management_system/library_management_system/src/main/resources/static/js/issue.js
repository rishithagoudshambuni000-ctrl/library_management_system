const API_URL = "http://localhost:8080/api/v1/issues";

// Load all issued books when page opens
window.onload = function () {
    loadIssuedBooks();
};

// ==========================
// ISSUE BOOK
// ==========================
async function issueBook() {

    const bookId = document.getElementById("bookId").value;
    const memberId = document.getElementById("memberId").value;
    const issueDate = document.getElementById("issueDate").value;
    const dueDate = document.getElementById("dueDate").value;

    if (bookId === "" || memberId === "" || issueDate === "" || dueDate === "") {
        alert("Please fill all fields");
        return;
    }

    try {

        const response = await fetch(API_URL, {

            method: "POST",

            headers: {
                "Content-Type": "application/json"
            },

            body: JSON.stringify({

                bookId: parseInt(bookId),
                memberId: parseInt(memberId),
                issueDate: issueDate,
                dueDate: dueDate

            })

        });

        const result = await response.json();

        alert(result.message);

        if (result.success) {

            document.getElementById("bookId").value = "";
            document.getElementById("memberId").value = "";
            document.getElementById("issueDate").value = "";
            document.getElementById("dueDate").value = "";

            loadIssuedBooks();

        }

    }

    catch (error) {

        console.log(error);
        alert("Unable to connect to server.");

    }

}

// ==========================
// LOAD ISSUED BOOKS
// ==========================
async function loadIssuedBooks() {

    try {

        const response = await fetch(API_URL);

        const issues = await response.json();

        const tableBody = document.getElementById("issueBody");

        tableBody.innerHTML = "";

        issues.forEach(issue => {

            tableBody.innerHTML += `

                <tr>

                    <td>${issue.issueId}</td>
                    <td>${issue.bookId}</td>
                    <td>${issue.memberId}</td>
                    <td>${issue.issueDate}</td>
                    <td>${issue.dueDate}</td>
                    <td>${issue.status}</td>

                    <td>

                        <button onclick="returnBook(${issue.issueId})">

                            Return

                        </button>

                    </td>

                </tr>

            `;

        });

    }

    catch (error) {

        console.log(error);
        alert("Unable to load issued books.");

    }

}

// ==========================
// RETURN BOOK
// ==========================
async function returnBook(issueId) {

    if (!confirm("Return this book?")) {
        return;
    }

    try {

        const response = await fetch(API_URL + "/" + issueId, {

            method: "PUT"

        });

        const result = await response.json();

        alert(result.message);

        loadIssuedBooks();

    }

    catch (error) {

        console.log(error);
        alert("Server Error");

    }

}