const API_URL = "http://localhost:8080/api/v1/members";

// ==========================
// Load Member Details
// ==========================
window.onload = async function () {

    const params = new URLSearchParams(window.location.search);

    const id = params.get("id");

    document.getElementById("memberId").value = id;

    try {

        const response = await fetch(API_URL + "/" + id);

        const member = await response.json();

        document.getElementById("name").value = member.name;
        document.getElementById("email").value = member.email;
        document.getElementById("phone").value = member.phone;
        document.getElementById("address").value = member.address;

    }

    catch(error){

        console.log(error);

        alert("Unable to load member.");

    }

}

// ==========================
// Update Member
// ==========================
async function updateMember(){

    const id = document.getElementById("memberId").value;

    const name = document.getElementById("name").value.trim();

    const email = document.getElementById("email").value.trim();

    const phone = document.getElementById("phone").value.trim();

    const address = document.getElementById("address").value.trim();

    if(name=="" || email=="" || phone=="" || address==""){

        alert("Please fill all fields");

        return;

    }

    try{

        const response = await fetch(API_URL + "/" + id,{

            method:"PUT",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify({

                name:name,

                email:email,

                phone:phone,

                address:address

            })

        });

        const result = await response.json();

        alert(result.message);

        if(result.success){

            window.location.href="members.html";

        }

    }

    catch(error){

        console.log(error);

        alert("Server Error");

    }

}