const API_URL = "http://localhost:8080/api/v1/members";

// ==========================
// LOAD MEMBERS
// ==========================
window.onload = function () {
    loadMembers();
};

async function loadMembers() {

    try {

        const response = await fetch(API_URL);

        const members = await response.json();

        const tableBody = document.getElementById("memberBody");

        tableBody.innerHTML = "";

        members.forEach(member => {

            tableBody.innerHTML += `

                <tr>

                    <td>${member.memberId}</td>
                    <td>${member.name}</td>
                    <td>${member.email}</td>
                    <td>${member.phone}</td>
                    <td>${member.address}</td>

                    <td>

                        <button class="edit"
                                onclick="editMember(${member.memberId})">

                            Edit

                        </button>

                        <button class="delete"
                                onclick="deleteMember(${member.memberId})">

                            Delete

                        </button>

                    </td>

                </tr>

            `;

        });

    } catch (error) {

        console.log(error);

        alert("Unable to load members.");

    }

}

// ==========================
// SEARCH MEMBER
// ==========================
function searchMember() {

    let input = document
        .getElementById("searchMember")
        .value
        .toLowerCase();

    let rows = document.querySelectorAll("#memberBody tr");

    rows.forEach(row => {

        let data = row.innerText.toLowerCase();

        row.style.display =
            data.includes(input) ? "" : "none";

    });

}

// ==========================
// DELETE MEMBER
// ==========================
async function deleteMember(id) {

    if (!confirm("Delete this member?")) {

        return;

    }

    try {

        const response = await fetch(API_URL + "/" + id, {

            method: "DELETE"

        });

        const result = await response.json();

        alert(result.message);

        loadMembers();

    } catch (error) {

        console.log(error);

        alert("Server Error");

    }

}

// ==========================
// EDIT MEMBER
// ==========================
function editMember(id) {

    window.location.href = "edit-member.html?id=" + id;

}