const API_URL = "http://localhost:8080/api/v1/members";

async function addMember(){

    const name = document.getElementById("name").value.trim();

    const email = document.getElementById("email").value.trim();

    const phone = document.getElementById("phone").value.trim();

    const address = document.getElementById("address").value.trim();

    if(name=="" || email=="" || phone=="" || address==""){

        alert("Please fill all fields");

        return;

    }

    try{

        const response = await fetch(API_URL,{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify({

                name:name,

                email:email,

                phone:phone,

                address:address

            })

        });

        const result = await response.json();

        alert(result.message);

        if(result.success){

            window.location.href="members.html";

        }

    }

    catch(error){

        console.log(error);

        alert("Unable to connect to server.");

    }

}