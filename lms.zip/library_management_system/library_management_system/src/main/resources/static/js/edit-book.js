const API_URL = "http://localhost:8080/api/v1/books";

// Get Book ID from URL
const params = new URLSearchParams(window.location.search);
const bookId = params.get("id");

// Load Book Details
window.onload = function () {

    fetch(API_URL + "/" + bookId)

        .then(response => response.json())

        .then(book => {

            document.getElementById("bookId").value = book.id;
            document.getElementById("title").value = book.title;
            document.getElementById("author").value = book.author;
            document.getElementById("category").value = book.category;
            document.getElementById("quantity").value = book.quantity;

        })

        .catch(error => {

            console.log(error);
            alert("Unable to load book.");

        });

}

// Update Book
function updateBook() {

    const book = {

        id: document.getElementById("bookId").value,
        title: document.getElementById("title").value,
        author: document.getElementById("author").value,
        category: document.getElementById("category").value,
        quantity: document.getElementById("quantity").value

    };

    fetch(API_URL + "/" + book.id, {

        method: "PUT",

        headers: {

            "Content-Type": "application/json"

        },

        body: JSON.stringify(book)

    })

        .then(response => response.json())

        .then(result => {

            alert(result.message);

            if (result.success) {

                window.location.href = "books.html";

            }

        })

        .catch(error => {

            console.log(error);

            alert("Server Error");

        });

}