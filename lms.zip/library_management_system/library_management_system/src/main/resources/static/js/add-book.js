const API_URL = "http://localhost:8080/api/v1/books";

async function addBook(){

    const title =
        document.getElementById("title").value.trim();

    const author =
        document.getElementById("author").value.trim();

    const category =
        document.getElementById("category").value.trim();

    const quantity =
        document.getElementById("quantity").value;

    if(title=="" || author=="" || category=="" || quantity==""){

        alert("Please fill all fields");

        return;

    }

    try{

        const response = await fetch(API_URL,{

            method:"POST",

            headers:{

                "Content-Type":"application/json"

            },

            body:JSON.stringify({

                title:title,

                author:author,

                category:category,

                quantity:quantity

            })

        });

        const result = await response.json();

        alert(result.message);

        if(result.success){

            window.location.href="books.html";

        }

    }

    catch(error){

        console.log(error);

        alert("Unable to connect to server.");

    }

}