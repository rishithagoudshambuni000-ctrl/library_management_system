const API_URL = "http://localhost:8080/api/v1/issues";

// Load issued books when page opens
window.onload = function () {
    loadReturnBooks();
};

// ==========================
// LOAD ISSUED BOOKS
// ==========================
async function loadReturnBooks() {

    try {

        const response = await fetch(API_URL);

        const issues = await response.json();

        const tableBody = document.getElementById("returnBody");

        tableBody.innerHTML = "";

        issues.forEach(issue => {

            // Show only books that are still issued
            if (issue.status === "Issued") {

                tableBody.innerHTML += `

                    <tr>

                        <td>${issue.issueId}</td>
                        <td>${issue.bookId}</td>
                        <td>${issue.memberId}</td>
                        <td>${issue.issueDate}</td>
                        <td>${issue.dueDate}</td>
                        <td>${issue.status}</td>

                        <td>

                            <button onclick="returnBook(${issue.issueId})">
                                Return
                            </button>

                        </td>

                    </tr>

                `;

            }

        });

    }

    catch (error) {

        console.log(error);

        alert("Unable to load issued books.");

    }

}

// ==========================
// RETURN BOOK
// ==========================
async function returnBook(issueId) {

    if (!confirm("Are you sure you want to return this book?")) {
        return;
    }

    try {

        const response = await fetch(API_URL + "/" + issueId, {

            method: "PUT"

        });

        const result = await response.json();

        alert(result.message);

        loadReturnBooks();

    }

    catch (error) {

        console.log(error);

        alert("Unable to return book.");

    }

}

// ==========================
// SEARCH
// ==========================
function searchReturnBook() {

    let input = document
        .getElementById("searchReturn")
        .value
        .toLowerCase();

    let rows = document.querySelectorAll("#returnBody tr");

    rows.forEach(row => {

        let text = row.innerText.toLowerCase();

        row.style.display = text.includes(input) ? "" : "none";

    });

}