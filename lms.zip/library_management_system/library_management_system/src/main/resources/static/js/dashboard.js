function logout() {
    alert("Logged out successfully");
    window.location.href = "login.html";
}

// demo values (later connect backend)
document.getElementById("totalBooks").innerText = 120;
document.getElementById("totalMembers").innerText = 45;
document.getElementById("issuedBooks").innerText = 30;
document.getElementById("availableBooks").innerText = 90;