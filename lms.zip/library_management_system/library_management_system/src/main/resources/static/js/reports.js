const API_URL = "http://localhost:8080/api/v1/reports";

// Load reports when page opens
window.onload = function () {
    loadReports();
};

// ==========================
// LOAD REPORTS
// ==========================
async function loadReports() {

    try {

        const response = await fetch(API_URL);

        const report = await response.json();

        document.getElementById("books").innerText = report.books;
        document.getElementById("members").innerText = report.members;
        document.getElementById("issued").innerText = report.issued;
        document.getElementById("returned").innerText = report.returned;

    }

    catch (error) {

        console.log(error);

        alert("Unable to load reports.");

    }

}