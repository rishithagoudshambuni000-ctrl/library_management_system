const API_URL = "http://localhost:8080/api/v1/users";

async function registerUser() {

    const username = document.getElementById("username").value.trim();
    const email = document.getElementById("email").value.trim();
    const phone = document.getElementById("phone").value.trim();
    const password = document.getElementById("password").value.trim();
    const confirmPassword = document.getElementById("confirmPassword").value.trim();

    if(username === "" || email === "" || phone === "" || password === "" || confirmPassword === ""){
        alert("Please fill all fields");
        return;
    }

    if(password !== confirmPassword){
        alert("Passwords do not match");
        return;
    }

    try{

        const response = await fetch(API_URL + "/register",{

            method:"POST",

            headers:{
                "Content-Type":"application/json"
            },

            body:JSON.stringify({
                username:username,
                email:email,
                phone:phone,
                password:password
            })

        });

        const message = await response.text();

        if(response.ok){

            alert(message);

            window.location.href = "login.html";

        }else{

            alert(result.message);

        }

    }catch(error){

        console.error(error);

        alert("Unable to connect to server.");

    }

}