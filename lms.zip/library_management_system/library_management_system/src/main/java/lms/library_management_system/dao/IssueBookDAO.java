package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import lms.library_management_system.model.IssueBook;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class IssueBookDAO {

    // ==========================
    // ISSUE BOOK
    // ==========================
    public boolean issueBook(IssueBook issueBook) {

        String sql = "INSERT INTO issued_books(book_id, member_id, issue_date, due_date, status) VALUES(?,?,?,?,?)";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, issueBook.getBookId());
            ps.setInt(2, issueBook.getMemberId());
            ps.setString(3, issueBook.getIssueDate());
            ps.setString(4, issueBook.getDueDate());
            ps.setString(5, "Issued");

            int rows = ps.executeUpdate();

            if (rows > 0) {

                PreparedStatement updateBook = con.prepareStatement(
                        "UPDATE books SET quantity = quantity - 1 WHERE book_id=? AND quantity>0"
                );

                updateBook.setInt(1, issueBook.getBookId());
                updateBook.executeUpdate();

                return true;
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==========================
    // GET ALL ISSUED BOOKS
    // ==========================
    public List<IssueBook> getAllIssuedBooks() {

        List<IssueBook> list = new ArrayList<>();

        String sql = "SELECT * FROM issued_books";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                IssueBook issue = new IssueBook();

                issue.setIssueId(rs.getInt("issue_id"));
                issue.setBookId(rs.getInt("book_id"));
                issue.setMemberId(rs.getInt("member_id"));
                issue.setIssueDate(rs.getString("issue_date"));
                issue.setDueDate(rs.getString("due_date"));
                issue.setReturnDate(rs.getString("return_date"));
                issue.setStatus(rs.getString("status"));

                list.add(issue);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return list;
    }

    // ==========================
    // RETURN BOOK
    // ==========================
    public boolean returnBook(int issueId) {

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement getBook = con.prepareStatement(
                    "SELECT book_id FROM issued_books WHERE issue_id=?"
            );

            getBook.setInt(1, issueId);

            ResultSet rs = getBook.executeQuery();

            if (rs.next()) {

                int bookId = rs.getInt("book_id");

                PreparedStatement updateIssue = con.prepareStatement(
                        "UPDATE issued_books SET status='Returned', return_date=CURDATE() WHERE issue_id=?"
                );

                updateIssue.setInt(1, issueId);

                int rows = updateIssue.executeUpdate();

                if (rows > 0) {

                    PreparedStatement updateBook = con.prepareStatement(
                            "UPDATE books SET quantity = quantity + 1 WHERE book_id=?"
                    );

                    updateBook.setInt(1, bookId);
                    updateBook.executeUpdate();

                    return true;
                }
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }
}