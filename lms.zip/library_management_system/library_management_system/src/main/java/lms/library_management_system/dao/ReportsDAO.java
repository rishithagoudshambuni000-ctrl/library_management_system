package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Repository
public class ReportsDAO {

    private int count(String sql) {

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            if (rs.next()) {
                return rs.getInt(1);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int totalBooks() {
        return count("SELECT COUNT(*) FROM books");
    }

    public int totalMembers() {
        return count("SELECT COUNT(*) FROM members");
    }

    public int totalIssuedBooks() {
        return count("SELECT COUNT(*) FROM issued_books WHERE status='Issued'");
    }

    public int totalReturnedBooks() {
        return count("SELECT COUNT(*) FROM issued_books WHERE status='Returned'");
    }
}