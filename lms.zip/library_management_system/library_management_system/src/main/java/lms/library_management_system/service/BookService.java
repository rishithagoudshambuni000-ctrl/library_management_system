package lms.library_management_system.service;

import lms.library_management_system.dao.BookDAO;
import lms.library_management_system.model.Book;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class BookService {

    private final BookDAO bookDAO;

    public BookService(BookDAO bookDAO) {
        this.bookDAO = bookDAO;
    }

    // ==========================
    // ADD BOOK
    // ==========================
    public boolean addBook(Book book) {
        return bookDAO.addBook(book);
    }

    // ==========================
    // GET ALL BOOKS
    // ==========================
    public List<Book> getAllBooks() {
        return bookDAO.getAllBooks();
    }

    // ==========================
    // GET BOOK BY ID
    // ==========================
    public Book getBookById(int id) {
        return bookDAO.getBookById(id);
    }

    // ==========================
    // UPDATE BOOK
    // ==========================
    public boolean updateBook(Book book) {
        return bookDAO.updateBook(book);
    }

    // ==========================
    // DELETE BOOK
    // ==========================
    public boolean deleteBook(int id) {
        return bookDAO.deleteBook(id);
    }

}