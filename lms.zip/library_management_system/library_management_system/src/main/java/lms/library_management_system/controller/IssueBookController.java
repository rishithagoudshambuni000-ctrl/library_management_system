package lms.library_management_system.controller;

import lms.library_management_system.model.IssueBook;
import lms.library_management_system.service.IssueBookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/issues")
@CrossOrigin(origins = "*")
public class IssueBookController {

    private final IssueBookService issueBookService;

    public IssueBookController(IssueBookService issueBookService) {
        this.issueBookService = issueBookService;
    }

    // ==========================
    // ISSUE BOOK
    // ==========================
    @PostMapping
    public ResponseEntity<?> issueBook(@RequestBody IssueBook issueBook) {

        Map<String, Object> response = new HashMap<>();

        boolean success = issueBookService.issueBook(issueBook);

        if (success) {
            response.put("success", true);
            response.put("message", "Book Issued Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Unable to Issue Book");
        }

        return ResponseEntity.ok(response);
    }

    // ==========================
    // GET ALL ISSUED BOOKS
    // ==========================
    @GetMapping
    public List<IssueBook> getAllIssuedBooks() {
        return issueBookService.getAllIssuedBooks();
    }

    // ==========================
    // RETURN BOOK
    // ==========================
    @PutMapping("/{id}")
    public ResponseEntity<?> returnBook(@PathVariable int id) {

        Map<String, Object> response = new HashMap<>();

        boolean success = issueBookService.returnBook(id);

        if (success) {
            response.put("success", true);
            response.put("message", "Book Returned Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Unable to Return Book");
        }

        return ResponseEntity.ok(response);
    }

}