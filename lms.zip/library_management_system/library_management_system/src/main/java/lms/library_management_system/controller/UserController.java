package lms.library_management_system.controller;

import lms.library_management_system.model.User;
import lms.library_management_system.service.UserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/users")
@CrossOrigin(origins = "*")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // ==========================
    // REGISTER
    // ==========================
    @PostMapping("/register")
    public ResponseEntity<?> register(@RequestBody User user) {

        Map<String, Object> response = new HashMap<>();

        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            response.put("success", false);
            response.put("message", "Username is required");
            return ResponseEntity.badRequest().body(response);
        }

        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            response.put("success", false);
            response.put("message", "Password is required");
            return ResponseEntity.badRequest().body(response);
        }

        boolean success = userService.register(user);

        if (success) {
            response.put("success", true);
            response.put("message", "Registration Successful");
            return ResponseEntity.ok(response);
        }

        response.put("success", false);
        response.put("message", "Username already exists");

        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    }

    // ==========================
    // LOGIN
    // ==========================
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {

        Map<String, Object> response = new HashMap<>();

        if (user.getUsername() == null || user.getUsername().trim().isEmpty()) {
            response.put("success", false);
            response.put("message", "Username is required");
            return ResponseEntity.badRequest().body(response);
        }

        if (user.getPassword() == null || user.getPassword().trim().isEmpty()) {
            response.put("success", false);
            response.put("message", "Password is required");
            return ResponseEntity.badRequest().body(response);
        }

        User loggedUser = userService.login(
                user.getUsername(),
                user.getPassword()
        );

        if (loggedUser != null) {

            response.put("success", true);
            response.put("message", "Login Successful");
            response.put("data", loggedUser);

            return ResponseEntity.ok(response);
        }

        response.put("success", false);
        response.put("message", "Invalid Username or Password");

        return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
    }

    // ==========================
    // TEST API
    // ==========================
    @GetMapping("/test")
    public ResponseEntity<?> test() {

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "Library Management System Backend is Running");

        return ResponseEntity.ok(response);
    }

}