package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import lms.library_management_system.model.User;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Repository
public class UserDAO {

    // ==========================
    // REGISTER
    // ==========================

    public boolean register(User user) {

        try (Connection con = DBConnection.getConnection()) {

            // Check if username already exists
            String checkSql = "SELECT * FROM users WHERE username=?";

            PreparedStatement checkPs = con.prepareStatement(checkSql);
            checkPs.setString(1, user.getUsername());

            ResultSet rs = checkPs.executeQuery();

            if (rs.next()) {
                return false;
            }

            // Insert user
            String insertSql =
                    "INSERT INTO users(username,email,phone,password) VALUES(?,?,?,?)";

            PreparedStatement ps = con.prepareStatement(insertSql);

            ps.setString(1, user.getUsername());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getPhone());
            ps.setString(4, user.getPassword());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println("========== REGISTER ERROR ==========");
            e.printStackTrace();
            System.out.println("====================================");

            return false;
        }
    }

    // ==========================
    // LOGIN
    // ==========================

    public User login(String username, String password) {

        String sql =
                "SELECT * FROM users WHERE username=? AND password=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                User user = new User();

                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setEmail(rs.getString("email"));
                user.setPhone(rs.getString("phone"));
                user.setPassword(rs.getString("password"));

                return user;
            }

        } catch (Exception e) {

            System.out.println("========== LOGIN ERROR ==========");
            e.printStackTrace();
            System.out.println("=================================");

        }

        return null;
    }

}