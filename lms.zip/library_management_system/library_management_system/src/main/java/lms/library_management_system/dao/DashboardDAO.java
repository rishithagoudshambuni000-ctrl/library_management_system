package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import lms.library_management_system.model.DashboardResponse;
import org.springframework.stereotype.Repository;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Repository
public class DashboardDAO {

    public DashboardResponse getDashboardData() {

        DashboardResponse response = new DashboardResponse();

        try (Connection con = DBConnection.getConnection()) {

            PreparedStatement ps1 =
                    con.prepareStatement("SELECT COUNT(*) FROM books");

            ResultSet rs1 = ps1.executeQuery();

            if(rs1.next())
                response.setBooks(rs1.getInt(1));

            PreparedStatement ps2 =
                    con.prepareStatement("SELECT COUNT(*) FROM members");

            ResultSet rs2 = ps2.executeQuery();

            if(rs2.next())
                response.setMembers(rs2.getInt(1));

            PreparedStatement ps3 =
                    con.prepareStatement("SELECT COUNT(*) FROM issued_books WHERE status='Issued'");

            ResultSet rs3 = ps3.executeQuery();

            if(rs3.next())
                response.setIssued(rs3.getInt(1));

            PreparedStatement ps4 =
                    con.prepareStatement("SELECT COUNT(*) FROM issued_books WHERE status='Returned'");

            ResultSet rs4 = ps4.executeQuery();

            if(rs4.next())
                response.setReturned(rs4.getInt(1));

        } catch (Exception e) {

            e.printStackTrace();

        }

        return response;

    }

}