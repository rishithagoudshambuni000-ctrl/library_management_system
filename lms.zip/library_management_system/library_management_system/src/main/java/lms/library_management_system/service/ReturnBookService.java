package lms.library_management_system.service;

import lms.library_management_system.dao.ReturnBookDAO;
import org.springframework.stereotype.Service;

@Service
public class ReturnBookService {

    private final ReturnBookDAO returnBookDAO;

    public ReturnBookService(ReturnBookDAO returnBookDAO) {
        this.returnBookDAO = returnBookDAO;
    }

    // =====================================
    // RETURN BOOK
    // =====================================

    public boolean returnBook(int issueId) {

        if (issueId <= 0) {
            return false;
        }

        return returnBookDAO.returnBook(issueId);

    }

}
