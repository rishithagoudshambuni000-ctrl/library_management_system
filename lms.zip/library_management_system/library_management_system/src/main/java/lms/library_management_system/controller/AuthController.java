package lms.library_management_system.controller;

import lms.library_management_system.model.LoginRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")

@CrossOrigin(origins = "*")
public class AuthController {

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginRequest request) {

        // Temporary Login

        if(request.getEmail().equals("admin@gmail.com")
                && request.getPassword().equals("admin123")){

            return ResponseEntity.ok("Login Successful");

        }

        return ResponseEntity
                .badRequest()
                .body("Invalid Email or Password");

    }

}