package lms.library_management_system.controller;

import lms.library_management_system.service.ReportsService;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/reports")
@CrossOrigin(origins = "*")
public class ReportsController {

    private final ReportsService reportsService;

    public ReportsController(ReportsService reportsService) {
        this.reportsService = reportsService;
    }

    @GetMapping
    public Map<String, Integer> getReport() {

        Map<String, Integer> report = new HashMap<>();

        report.put("books", reportsService.totalBooks());
        report.put("members", reportsService.totalMembers());
        report.put("issued", reportsService.totalIssuedBooks());
        report.put("returned", reportsService.totalReturnedBooks());

        return report;
    }
}