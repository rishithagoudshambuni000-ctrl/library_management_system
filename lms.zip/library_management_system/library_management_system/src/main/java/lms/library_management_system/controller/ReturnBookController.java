package lms.library_management_system.controller;

import lms.library_management_system.service.ReturnBookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/returns")
@CrossOrigin(origins = "*")
public class ReturnBookController {

    private final ReturnBookService returnBookService;

    public ReturnBookController(ReturnBookService returnBookService) {
        this.returnBookService = returnBookService;
    }

    // =====================================
    // RETURN BOOK
    // =====================================

    @PutMapping("/{issueId}")
    public ResponseEntity<Map<String, Object>> returnBook(@PathVariable int issueId) {

        Map<String, Object> response = new HashMap<>();

        boolean returned = returnBookService.returnBook(issueId);

        if (returned) {

            response.put("success", true);
            response.put("message", "Book returned successfully.");

        } else {

            response.put("success", false);
            response.put("message", "Unable to return the book.");

        }

        return ResponseEntity.ok(response);
    }
}
