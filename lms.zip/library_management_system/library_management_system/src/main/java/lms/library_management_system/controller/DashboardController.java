package lms.library_management_system.controller;

import org.springframework.web.bind.annotation.*;
import java.util.*;

@RestController
@RequestMapping("/api/dashboard")
public class DashboardController {

    @GetMapping("/stats")
    public Map<String, Integer> getStats() {

        Map<String, Integer> stats = new HashMap<>();

        // TODO: replace with DB logic later
        stats.put("books", 10);
        stats.put("members", 5);
        stats.put("issued", 3);
        stats.put("returned", 2);

        return stats;
    }
    @GetMapping("/chart")
    public Map<String, Object> getChartData() {

        Map<String, Object> data = new HashMap<>();

        List<String> labels = Arrays.asList("Jan", "Feb", "Mar");
        List<Integer> values = Arrays.asList(5, 8, 3);

        data.put("labels", labels);
        data.put("values", values);

        return data;
    }
}