package lms.library_management_system.service;

import lms.library_management_system.dao.DashboardDAO;
import lms.library_management_system.model.DashboardResponse;
import org.springframework.stereotype.Service;

@Service
public class DashboardService {

    private final DashboardDAO dashboardDAO;

    public DashboardService(DashboardDAO dashboardDAO) {

        this.dashboardDAO = dashboardDAO;

    }

    public DashboardResponse getDashboardData() {

        return dashboardDAO.getDashboardData();

    }

}