package lms.library_management_system.service;

import lms.library_management_system.dao.UserDAO;
import lms.library_management_system.model.User;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    private final UserDAO userDAO;

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    // ==========================
    // REGISTER USER
    // ==========================

    public boolean register(User user) {
        return userDAO.register(user);
    }

    // ==========================
    // LOGIN USER
    // ==========================

    public User login(String username, String password) {
        return userDAO.login(username, password);
    }

}