package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import lms.library_management_system.model.Member;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class MemberDAO {

    // ==========================
    // ADD MEMBER
    // ==========================
    public boolean addMember(Member member) {

        String sql = "INSERT INTO members(name,email,phone,address) VALUES(?,?,?,?)";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getAddress());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==========================
    // GET ALL MEMBERS
    // ==========================
    public List<Member> getAllMembers() {

        List<Member> members = new ArrayList<>();

        String sql = "SELECT * FROM members";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Member member = new Member();

                member.setMemberId(rs.getInt("member_id"));
                member.setName(rs.getString("name"));
                member.setEmail(rs.getString("email"));
                member.setPhone(rs.getString("phone"));
                member.setAddress(rs.getString("address"));

                members.add(member);
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return members;
    }

    // ==========================
    // GET MEMBER BY ID
    // ==========================
    public Member getMemberById(int id) {

        String sql = "SELECT * FROM members WHERE member_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Member member = new Member();

                member.setMemberId(rs.getInt("member_id"));
                member.setName(rs.getString("name"));
                member.setEmail(rs.getString("email"));
                member.setPhone(rs.getString("phone"));
                member.setAddress(rs.getString("address"));

                return member;
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return null;
    }

    // ==========================
    // UPDATE MEMBER
    // ==========================
    public boolean updateMember(Member member) {

        String sql = "UPDATE members SET name=?,email=?,phone=?,address=? WHERE member_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, member.getName());
            ps.setString(2, member.getEmail());
            ps.setString(3, member.getPhone());
            ps.setString(4, member.getAddress());
            ps.setInt(5, member.getMemberId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==========================
    // DELETE MEMBER
    // ==========================
    public boolean deleteMember(int id) {

        String sql = "DELETE FROM members WHERE member_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

}