package lms.library_management_system.dao;

import lms.library_management_system.config.DBConnection;
import lms.library_management_system.model.Book;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

@Repository
public class BookDAO {

    // ==========================
    // ADD BOOK
    // ==========================
    public boolean addBook(Book book) {

        String sql =
                "INSERT INTO books(title,author,category,quantity,available_quantity) VALUES(?,?,?,?,?)";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getCategory());
            ps.setInt(4, book.getQuantity());
            ps.setInt(5, book.getQuantity());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==========================
    // GET ALL BOOKS
    // ==========================
    public List<Book> getAllBooks() {

        List<Book> books = new ArrayList<>();

        String sql = "SELECT * FROM books";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {

            while (rs.next()) {

                Book book = new Book();

                book.setId(rs.getInt("book_id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category"));
                book.setQuantity(rs.getInt("quantity"));
                book.setAvailableQuantity(
                        rs.getInt("available_quantity")
                );

                books.add(book);

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return books;
    }

    // ==========================
    // GET BOOK BY ID
    // ==========================
    public Book getBookById(int id) {

        String sql =
                "SELECT * FROM books WHERE book_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, id);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                Book book = new Book();

                book.setId(rs.getInt("book_id"));
                book.setTitle(rs.getString("title"));
                book.setAuthor(rs.getString("author"));
                book.setCategory(rs.getString("category"));
                book.setQuantity(rs.getInt("quantity"));

                return book;
            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return null;
    }

    // ==========================
    // UPDATE BOOK
    // ==========================
    public boolean updateBook(Book book) {

        String sql =
                "UPDATE books SET title=?,author=?,category=?,quantity=? WHERE book_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setString(1, book.getTitle());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getCategory());
            ps.setInt(4, book.getQuantity());
            ps.setInt(5, book.getId());

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }

    // ==========================
    // DELETE BOOK
    // ==========================
    public boolean deleteBook(int id) {

        String sql =
                "DELETE FROM books WHERE book_id=?";

        try (
                Connection con = DBConnection.getConnection();
                PreparedStatement ps = con.prepareStatement(sql)
        ) {

            ps.setInt(1, id);

            return ps.executeUpdate() > 0;

        } catch (Exception e) {

            e.printStackTrace();

        }

        return false;
    }
}