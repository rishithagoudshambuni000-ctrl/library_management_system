package lms.library_management_system.exception;

public class IssueBookNotFoundException extends RuntimeException {

    public IssueBookNotFoundException(String message) {
        super(message);
    }
}