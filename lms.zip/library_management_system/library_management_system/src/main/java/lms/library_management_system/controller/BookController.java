package lms.library_management_system.controller;

import lms.library_management_system.model.Book;
import lms.library_management_system.service.BookService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/books")
@CrossOrigin(origins = "*")
public class BookController {

    private final BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    // ==========================
    // ADD BOOK
    // ==========================
    @PostMapping
    public ResponseEntity<?> addBook(@RequestBody Book book) {

        Map<String, Object> response = new HashMap<>();

        boolean success = bookService.addBook(book);

        if (success) {
            response.put("success", true);
            response.put("message", "Book Added Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Unable to Add Book");
        }

        return ResponseEntity.ok(response);
    }

    // ==========================
    // GET ALL BOOKS
    // ==========================
    @GetMapping
    public List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }

    // ==========================
    // GET BOOK BY ID
    // ==========================
    @GetMapping("/{id}")
    public ResponseEntity<?> getBookById(@PathVariable int id) {

        Book book = bookService.getBookById(id);

        if (book != null) {
            return ResponseEntity.ok(book);
        }

        return ResponseEntity.notFound().build();
    }

    // ==========================
    // UPDATE BOOK
    // ==========================
    @PutMapping("/{id}")
    public ResponseEntity<?> updateBook(@PathVariable int id,
                                        @RequestBody Book book) {

        book.setId(id);

        Map<String, Object> response = new HashMap<>();

        boolean success = bookService.updateBook(book);

        if (success) {

            response.put("success", true);
            response.put("message", "Book Updated Successfully");

        } else {

            response.put("success", false);
            response.put("message", "Unable to Update Book");

        }

        return ResponseEntity.ok(response);
    }

    // ==========================
    // DELETE BOOK
    // ==========================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteBook(@PathVariable int id) {

        Map<String, Object> response = new HashMap<>();

        boolean success = bookService.deleteBook(id);

        if (success) {

            response.put("success", true);
            response.put("message", "Book Deleted Successfully");

        } else {

            response.put("success", false);
            response.put("message", "Book Not Found");

        }

        return ResponseEntity.ok(response);
    }

}