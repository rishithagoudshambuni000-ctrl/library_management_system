package lms.library_management_system.dao;

import org.springframework.stereotype.Repository;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@Repository
public class ReturnBookDAO {

    private final DataSource dataSource;

    public ReturnBookDAO(DataSource dataSource) {
        this.dataSource = dataSource;
    }

    // =====================================
    // RETURN BOOK
    // =====================================

    public boolean returnBook(int issueId) {

        Connection con = null;

        try {

            con = dataSource.getConnection();

            con.setAutoCommit(false);

            // ---------------------------------
            // Get Book ID
            // ---------------------------------

            String getBookSql =
                    "SELECT book_id FROM issued_books WHERE issue_id=?";

            PreparedStatement ps1 =
                    con.prepareStatement(getBookSql);

            ps1.setInt(1, issueId);

            ResultSet rs = ps1.executeQuery();

            if (!rs.next()) {

                return false;

            }

            int bookId = rs.getInt("book_id");

            // ---------------------------------
            // Update Issue Status
            // ---------------------------------

            String updateIssue =

                    "UPDATE issued_books " +

                            "SET status='Returned', " +

                            "return_date=CURDATE() " +

                            "WHERE issue_id=?";

            PreparedStatement ps2 =
                    con.prepareStatement(updateIssue);

            ps2.setInt(1, issueId);

            ps2.executeUpdate();

            // ---------------------------------
            // Increase Book Quantity
            // ---------------------------------

            String updateBook =

                    "UPDATE books " +

                            "SET quantity=quantity+1 " +

                            "WHERE book_id=?";

            PreparedStatement ps3 =
                    con.prepareStatement(updateBook);

            ps3.setInt(1, bookId);

            ps3.executeUpdate();

            con.commit();

            return true;

        }

        catch (Exception e) {

            e.printStackTrace();

            try {

                if (con != null)

                    con.rollback();

            }

            catch (Exception ex) {

                ex.printStackTrace();

            }

        }

        finally {

            try {

                if (con != null)

                    con.close();

            }

            catch (Exception e) {

                e.printStackTrace();

            }

        }

        return false;

    }

}