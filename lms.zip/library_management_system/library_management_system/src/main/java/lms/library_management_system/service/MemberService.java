package lms.library_management_system.service;

import lms.library_management_system.dao.MemberDAO;
import lms.library_management_system.model.Member;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MemberService {

    private final MemberDAO memberDAO;

    public MemberService(MemberDAO memberDAO) {
        this.memberDAO = memberDAO;
    }

    // ==========================
    // ADD MEMBER
    // ==========================
    public boolean addMember(Member member) {
        return memberDAO.addMember(member);
    }

    // ==========================
    // GET ALL MEMBERS
    // ==========================
    public List<Member> getAllMembers() {
        return memberDAO.getAllMembers();
    }

    // ==========================
    // GET MEMBER BY ID
    // ==========================
    public Member getMemberById(int id) {
        return memberDAO.getMemberById(id);
    }

    // ==========================
    // UPDATE MEMBER
    // ==========================
    public boolean updateMember(Member member) {
        return memberDAO.updateMember(member);
    }

    // ==========================
    // DELETE MEMBER
    // ==========================
    public boolean deleteMember(int id) {
        return memberDAO.deleteMember(id);
    }

}