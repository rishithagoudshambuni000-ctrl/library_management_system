package lms.library_management_system.service;

import lms.library_management_system.dao.ReportsDAO;
import org.springframework.stereotype.Service;

@Service
public class ReportsService {

    private final ReportsDAO reportsDAO;

    public ReportsService(ReportsDAO reportsDAO) {
        this.reportsDAO = reportsDAO;
    }

    public int totalBooks() {
        return reportsDAO.totalBooks();
    }

    public int totalMembers() {
        return reportsDAO.totalMembers();
    }

    public int totalIssuedBooks() {
        return reportsDAO.totalIssuedBooks();
    }

    public int totalReturnedBooks() {
        return reportsDAO.totalReturnedBooks();
    }
}