package lms.library_management_system.controller;

import lms.library_management_system.model.Member;
import lms.library_management_system.service.MemberService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/v1/members")
@CrossOrigin(origins = "*")
public class MemberController {

    private final MemberService memberService;

    public MemberController(MemberService memberService) {
        this.memberService = memberService;
    }

    // ==========================
    // ADD MEMBER
    // ==========================
    @PostMapping
    public ResponseEntity<?> addMember(@RequestBody Member member) {

        Map<String, Object> response = new HashMap<>();

        boolean success = memberService.addMember(member);

        if (success) {
            response.put("success", true);
            response.put("message", "Member Added Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Unable to Add Member");
        }

        return ResponseEntity.ok(response);
    }

    // ==========================
    // GET ALL MEMBERS
    // ==========================
    @GetMapping
    public List<Member> getAllMembers() {
        return memberService.getAllMembers();
    }

    // ==========================
    // GET MEMBER BY ID
    // ==========================
    @GetMapping("/{id}")
    public ResponseEntity<?> getMemberById(@PathVariable int id) {

        Member member = memberService.getMemberById(id);

        if (member != null) {
            return ResponseEntity.ok(member);
        }

        return ResponseEntity.notFound().build();
    }

    // ==========================
    // UPDATE MEMBER
    // ==========================
    @PutMapping("/{id}")
    public ResponseEntity<?> updateMember(@PathVariable int id,
                                          @RequestBody Member member) {

        member.setMemberId(id);

        Map<String, Object> response = new HashMap<>();

        boolean success = memberService.updateMember(member);

        if (success) {
            response.put("success", true);
            response.put("message", "Member Updated Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Unable to Update Member");
        }

        return ResponseEntity.ok(response);
    }

    // ==========================
    // DELETE MEMBER
    // ==========================
    @DeleteMapping("/{id}")
    public ResponseEntity<?> deleteMember(@PathVariable int id) {

        Map<String, Object> response = new HashMap<>();

        boolean success = memberService.deleteMember(id);

        if (success) {
            response.put("success", true);
            response.put("message", "Member Deleted Successfully");
        } else {
            response.put("success", false);
            response.put("message", "Member Not Found");
        }

        return ResponseEntity.ok(response);
    }

}