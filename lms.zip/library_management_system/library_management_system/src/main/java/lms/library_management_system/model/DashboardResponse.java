package lms.library_management_system.model;

public class DashboardResponse {

    private int books;
    private int members;
    private int issued;
    private int returned;

    public DashboardResponse() {
    }

    public DashboardResponse(int books, int members, int issued, int returned) {
        this.books = books;
        this.members = members;
        this.issued = issued;
        this.returned = returned;
    }

    public int getBooks() {
        return books;
    }

    public void setBooks(int books) {
        this.books = books;
    }

    public int getMembers() {
        return members;
    }

    public void setMembers(int members) {
        this.members = members;
    }

    public int getIssued() {
        return issued;
    }

    public void setIssued(int issued) {
        this.issued = issued;
    }

    public int getReturned() {
        return returned;
    }

    public void setReturned(int returned) {
        this.returned = returned;
    }

}