package lms.library_management_system.service;

import lms.library_management_system.dao.IssueBookDAO;
import lms.library_management_system.model.IssueBook;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class IssueBookService {

    private final IssueBookDAO issueBookDAO;

    public IssueBookService(IssueBookDAO issueBookDAO) {
        this.issueBookDAO = issueBookDAO;
    }

    // ==========================
    // ISSUE BOOK
    // ==========================
    public boolean issueBook(IssueBook issueBook) {
        return issueBookDAO.issueBook(issueBook);
    }

    // ==========================
    // GET ALL ISSUED BOOKS
    // ==========================
    public List<IssueBook> getAllIssuedBooks() {
        return issueBookDAO.getAllIssuedBooks();
    }

    // ==========================
    // RETURN BOOK
    // ==========================
    public boolean returnBook(int issueId) {
        return issueBookDAO.returnBook(issueId);
    }

}